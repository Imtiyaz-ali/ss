#include<stdio.h>
#include<string.h>
#include<stdlib.h>


void main() {
	FILE *input,*symtab,*optab,*interm;
	int locctr,startadd,op1,o,len;
	char opcode[20],label[20],operand[20],otp[20];
	input = fopen("input.asm","r");
	symtab = fopen("symboltable.symtab","w");
	interm = fopen("intermediate.txt","w");
	fscanf(input,"%s%s%x",label,opcode,&op1);
	if(strcmp(opcode,"START")==0) {
		startadd=op1;
		locctr=startadd;
		printf("%x\t%s\t%s\t%x\n",locctr,label,opcode,op1);
	} else {
		locctr=0;
	}
	fprintf(interm,"%x\t%s\t%s\t%x\n",locctr,label,opcode,op1);
	fscanf(input,"%s%s",label,opcode);
	while(!feof(input)) {
		fscanf(input,"%s",operand);
		fprintf(interm,"%x\t%s\t%s\t%s\n",locctr,label,opcode,operand);
		printf("%x\t%s\t%s\t%s\n",locctr,label,opcode,operand);
		if(strcmp(label,"**")!=0) {
			fprintf(symtab,"%x\t%s\n",locctr,label);
		}
		if(strcmp(opcode,"END")==0) {
			printf("program length=%x\n",(locctr-startadd));
			break;
		}
		optab=fopen("operationtable.optab","r");
		fscanf(optab,"%s%x",otp,&o);
		while(!feof(optab)) {
			if(strcmp(opcode,otp)==0) {
				locctr=locctr+3;
				break;
			}
			fscanf(optab,"%s%x",otp,&o);
		}
		fclose(optab);
		if(!strcmp(opcode,"WORD")) {
			locctr=locctr+3;
		} else if(!strcmp(opcode,"RESW")) {
			op1=atoi(operand);
			locctr=locctr+(3*op1);
		} else if(!strcmp(opcode,"BYTE")) {
			if(operand[0]=='X') {
				len=strlen(operand)-3;
				locctr=locctr+len/2;
			} else {
				len=strlen(operand)-3;
				locctr=locctr+len;
			}
		} else if(!strcmp(opcode,"RESB")) {
			op1=atoi(operand);
			locctr=locctr+op1;
		}
		fscanf(input,"%s%s",label,opcode);
	}
	fclose(input);
	fclose(symtab);
	fclose(interm);
}

